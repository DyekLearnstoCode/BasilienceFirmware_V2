
#include <Firebase_ESP_Client.h>
#include <WiFi.h>
#include "Config.h"
#include "Globals.h"


void FirebaseManager::begin()
{
    Serial.println();
    Serial.println("Connecting WiFi...");

    WiFi.begin(
        WIFI_SSID,
        WIFI_PASSWORD);

    while(WiFi.status() !=
          WL_CONNECTED)
    {
        delay(500);

        Serial.print(".");
    }

    Serial.println();
    Serial.println(
        "WiFi Connected");

    systemState.wifiConnected =
    true;

    Serial.print(
        "IP Address: ");

    Serial.println(
        WiFi.localIP());

    config.api_key =
    API_KEY;

    config.database_url =
        DATABASE_URL;

    if (Firebase.signUp(
            &config,
            &auth,
            "",
            ""))
    {
        Serial.println(
            "Firebase SignUp OK");
    }
    else
    {
        Serial.print(
            "Firebase SignUp Failed: ");

        Serial.println(
            config.signer.signupError.message.c_str());
    }

    Firebase.begin(
        &config,
        &auth);

    Firebase.reconnectWiFi(
        true);

    systemState.firebaseConnected =
    true;

    Serial.println(
        "Firebase Started");
}

void FirebaseManager::update()
{

    systemState.firebaseConnected =
    Firebase.ready();

    
    if(!Firebase.ready())
        return;

    if(millis() - lastSettingsRead >= 60000)
    {
        lastSettingsRead = millis();

        readSettings();
    }

    readCommands();
    writeDeviceInfo();
    writeSensors();

    writeStatus();

    writeTelemetry();

    writeAlerts();
    writeActuators();
}

void FirebaseManager::readSettings()
{
    String root =
        "/devices/" +
        String(DEVICE_ID);

    String path =
        root +
        "/settings";

    if(!Firebase.RTDB.getJSON(
        &fbdo,
        path))
    {
        return;
    }

    FirebaseJsonData data;

    fbdo.jsonObject().get(
        data,
        "lightOnHour");

    systemState.lightOnHour =
        data.intValue;

    fbdo.jsonObject().get(
        data,
        "lightOnMinute");

    systemState.lightOnMinute =
        data.intValue;

    fbdo.jsonObject().get(
        data,
        "lightOffHour");

    systemState.lightOffHour =
        data.intValue;

    fbdo.jsonObject().get(
        data,
        "lightOffMinute");

    systemState.lightOffMinute =
        data.intValue;

    fbdo.jsonObject().get(
        data,
        "minPH");

    systemState.minPH =
        data.floatValue;

    fbdo.jsonObject().get(
        data,
        "maxPH");

    systemState.maxPH =
        data.floatValue;

    fbdo.jsonObject().get(
        data,
        "minEC");

    systemState.minEC =
        data.floatValue;

    fbdo.jsonObject().get(
    data,
    "refillStartLevel");

    systemState.refillStartLevel =
        data.floatValue;

    fbdo.jsonObject().get(
        data,
        "refillStopLevel");

    systemState.refillStopLevel =
        data.floatValue;

    fbdo.jsonObject().get(
        data,
        "highWaterTemp");

    systemState.highWaterTemp =
        data.floatValue;

    fbdo.jsonObject().get(
        data,
        "coolerOffTemp");

    systemState.coolerOffTemp =
        data.floatValue;
}

void FirebaseManager::readCommands()
{
    static unsigned long lastCommandRead = 0;

    if(millis() - lastCommandRead < 5000)
        return;

    lastCommandRead = millis();

    String root =
        "/devices/" +
        String(DEVICE_ID);

    String path =
        root +
        "/commands";

    if(!Firebase.RTDB.getJSON(
        &fbdo,
        path))
    {
        return;
    }

    FirebaseJsonData data;

    // ==========================
    // Manual Mode
    // ==========================

    fbdo.jsonObject().get(
        data,
        "manualMode");

    systemState.manualMode =
        data.boolValue;

    // ==========================
    // Force Refill
    // ==========================

    fbdo.jsonObject().get(
    data,
    "forceRefill");

    if(data.boolValue)  
    {
        systemState.forceRefill =
            true;

        Firebase.RTDB.setBool(
            &fbdo,
            root + "/commands/forceRefill",
            false);
    }

    fbdo.jsonObject().get(
    data,
    "restartESP");

    if(data.boolValue)
    {
        Firebase.RTDB.setBool(
            &fbdo,
            root + "/commands/restartESP",
            false);

        Serial.println(
            "ESP RESTART REQUESTED");

        delay(1000);

        ESP.restart();
    }

    fbdo.jsonObject().get(
    data,
    "resetSafetyLock");

    if(data.boolValue)
    {
        systemState.resetSafetyLock =
            true;

        Firebase.RTDB.setBool(
            &fbdo,
            root + "/commands/resetSafetyLock",
            false);
    }

    // ==========================
    // Manual Actuators
    // ==========================

    if(systemState.manualMode)
    {
        fbdo.jsonObject().get(
            data,
            "fogger");

        if(data.boolValue)
            actuatorManager.turnOn(
                FOGGER);
        else
            actuatorManager.turnOff(
                FOGGER);

        fbdo.jsonObject().get(
            data,
            "blower");

        if(data.boolValue)
            actuatorManager.turnOn(
                BLOWER);
        else
            actuatorManager.turnOff(
                BLOWER);

        fbdo.jsonObject().get(
            data,
            "growLight");

        if(data.boolValue)
            actuatorManager.turnOn(
                GROW_LIGHT);
        else
            actuatorManager.turnOff(
                GROW_LIGHT);

        fbdo.jsonObject().get(
        data,
        "solenoid");

        if(data.boolValue)
            actuatorManager.turnOn(
                SOLENOID);
        else
            actuatorManager.turnOff(
                SOLENOID);


        fbdo.jsonObject().get(
            data,
            "growPump");

        if(data.boolValue)
            actuatorManager.turnOn(
                GROW_PUMP);
        else
            actuatorManager.turnOff(
                GROW_PUMP);

        fbdo.jsonObject().get(
        data,
        "bloomPump");

        if(data.boolValue)
            actuatorManager.turnOn(
                BLOOM_PUMP);
        else
            actuatorManager.turnOff(
                BLOOM_PUMP);

            fbdo.jsonObject().get(
        data,
                "phUpPump");

        if(data.boolValue)
            actuatorManager.turnOn(
                PH_UP_PUMP);
        else
            actuatorManager.turnOff(
                PH_UP_PUMP);


                fbdo.jsonObject().get(
            data,
            "phDownPump");

        if(data.boolValue)
            actuatorManager.turnOn(
                PH_DOWN_PUMP);
        else
            actuatorManager.turnOff(
                PH_DOWN_PUMP);


                fbdo.jsonObject().get(
            data,
            "peltier");

        if(data.boolValue)
            actuatorManager.turnOn(
                PELTIER);
        else
            actuatorManager.turnOff(
                PELTIER);

    }

    //get time
    fbdo.jsonObject().get(
    data,
    "syncRTC");

    if(data.boolValue)
    {
        syncRTC();

        Firebase.RTDB.setBool(
            &fbdo,
            root + "/commands/syncRTC",
            false);
    }

}

void FirebaseManager::syncRTC()
{

     String root =
        "/devices/" +
        String(DEVICE_ID);

    String path =
        root +
        "/rtc";

    FirebaseJsonData data;

    if(!Firebase.RTDB.getJSON(
        &fbdo,
        path))
    {
        Serial.println(
            "RTC SYNC FAILED");

        return;
    }

    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t hour;
    uint8_t minute;
    uint8_t second;

    fbdo.jsonObject().get(
        data,
        "year");
    year = data.intValue;

    fbdo.jsonObject().get(
        data,
        "month");
    month = data.intValue;

    fbdo.jsonObject().get(
        data,
        "day");
    day = data.intValue;

    fbdo.jsonObject().get(
        data,
        "hour");
    hour = data.intValue;

    fbdo.jsonObject().get(
        data,
        "minute");
    minute = data.intValue;

    fbdo.jsonObject().get(
        data,
        "second");
    second = data.intValue;

    rtcManager.setDateTime(
        year,
        month,
        day,
        hour,
        minute,
        second);

    Serial.println(
        "RTC SYNC SUCCESS");
}

void FirebaseManager::writeSensors()
{
    static unsigned long lastSensorUpload = 0;

    if(millis() - lastSensorUpload < 10000)
        return;

    lastSensorUpload = millis();

    FirebaseJson sensorJson;

    sensorJson.set(
        "airTemperature",
        sensors.temperature);

    sensorJson.set(
        "humidity",
        sensors.humidity);

    sensorJson.set(
        "waterTemperature",
        sensors.waterTemp);

    sensorJson.set(
        "waterLevel",
        sensors.waterLevel);

    sensorJson.set(
        "ec",
        sensors.ec);

    sensorJson.set(
        "tds",
        sensors.tds);

    sensorJson.set(
        "ph",
        sensors.ph);

    sensorJson.set(
    "timestamp",
    millis());

    String root =
    "/devices/" +
    String(DEVICE_ID);

    if(Firebase.RTDB.setJSON(
        &fbdo,
        root + "/sensors",
        &sensorJson))
        {
            Serial.println(
                "Sensors Uploaded");
        }
}

void FirebaseManager::writeStatus()
{
    static unsigned long lastStatusUpload = 0;

    if(millis() - lastStatusUpload < 10000)
        return;

    lastStatusUpload = millis();

    FirebaseJson statusJson;

    statusJson.set(
    "currentMode",
    (int)systemState.currentMode);

    statusJson.set(
        "manualMode",
        systemState.manualMode);

    statusJson.set(
        "reservoirLocked",
        systemState.reservoirLocked);

    statusJson.set(
    "safetyLock",
    systemState.safetyLock);

    statusJson.set(
        "wifiConnected",
        systemState.wifiConnected);

    statusJson.set(
        "firebaseConnected",
        systemState.firebaseConnected);

    String root =
    "/devices/" +
    String(DEVICE_ID);

    if(Firebase.RTDB.setJSON(
        &fbdo,
        root + "/status",
        &statusJson))
        {
            Serial.println(
                "Status Uploaded");
        }
}

void FirebaseManager::writeTelemetry()
{
    static unsigned long
        lastTelemetryUpload = 0;

    if(millis() -
       lastTelemetryUpload <
       10000)
    {
        return;
    }

    lastTelemetryUpload =
        millis();

    String root =
        "/devices/" +
        String(DEVICE_ID);

    FirebaseJson telemetryJson;

    telemetryJson.set(
        "phAttempts",
        systemState.phAttempts);

    telemetryJson.set(
        "ecAttempts",
        systemState.ecAttempts);

    telemetryJson.set(
        "phDoseTime",
        systemState.phDoseTime);

    telemetryJson.set(
        "ecDoseTime",
        systemState.ecDoseTime);

    Firebase.RTDB.setJSON(
        &fbdo,
        root + "/telemetry",
        &telemetryJson);
}

void FirebaseManager::writeAlerts()
{
    String root =
    "/devices/" +
    String(DEVICE_ID);

    static unsigned long lastAlertUpload = 0;

    if(millis() - lastAlertUpload < 10000)
        return;

    lastAlertUpload = millis();

    FirebaseJson alertJson;

    alertJson.set(
        "lowWater",
        alertState.lowWater);

    alertJson.set(
        "ecLow",
        alertState.ecLow);

    alertJson.set(
        "phOutOfRange",
        alertState.phOutOfRange);

    alertJson.set(
        "waterTempOutOfRange",
        alertState.waterTempOutOfRange);

    alertJson.set(
        "highTemperature",
        alertState.highTemperature);

    alertJson.set(
        "sensorFault",
        alertState.sensorFault);

    if(Firebase.RTDB.setJSON(
        &fbdo,
        root + "/alerts",
        &alertJson))
    {
        Serial.println(
            "Alerts Uploaded");
    }
}

void FirebaseManager::writeActuators()
{
    String root =
    "/devices/" +
    String(DEVICE_ID);
    
    ActuatorTelemetry current;

    current.fogger =
        actuatorManager.isOn(
            FOGGER);

    current.growLight =
        actuatorManager.isOn(
            GROW_LIGHT);

    current.blower =
        actuatorManager.isOn(
            BLOWER);

    current.solenoid =
        actuatorManager.isOn(
            SOLENOID);

    current.growPump =
        actuatorManager.isOn(
            GROW_PUMP);

    current.bloomPump =
        actuatorManager.isOn(
            BLOOM_PUMP);

    current.phUpPump =
        actuatorManager.isOn(
            PH_UP_PUMP);

    current.phDownPump =
        actuatorManager.isOn(
            PH_DOWN_PUMP);

    current.peltier =
        actuatorManager.isOn(
            PELTIER);

    bool changed = false;

    if(current.fogger !=
       lastActuatorState.fogger)
        changed = true;

    if(current.growLight !=
       lastActuatorState.growLight)
        changed = true;

    if(current.blower !=
       lastActuatorState.blower)
        changed = true;

    if(current.solenoid !=
       lastActuatorState.solenoid)
        changed = true;

    if(current.growPump !=
       lastActuatorState.growPump)
        changed = true;

    if(current.bloomPump !=
       lastActuatorState.bloomPump)
        changed = true;

    if(current.phUpPump !=
       lastActuatorState.phUpPump)
        changed = true;

    if(current.phDownPump !=
       lastActuatorState.phDownPump)
        changed = true;

    if(current.peltier !=
       lastActuatorState.peltier)
        changed = true;

    if(!changed)
        return;

    FirebaseJson actuatorJson;

    actuatorJson.set(
        "fogger",
        current.fogger);

    actuatorJson.set(
        "growLight",
        current.growLight);

    actuatorJson.set(
        "blower",
        current.blower);

    actuatorJson.set(
        "solenoid",
        current.solenoid);

    actuatorJson.set(
        "growPump",
        current.growPump);

    actuatorJson.set(
        "bloomPump",
        current.bloomPump);

    actuatorJson.set(
        "phUpPump",
        current.phUpPump);

    actuatorJson.set(
        "phDownPump",
        current.phDownPump);

    actuatorJson.set(
        "peltier",
        current.peltier);

    if(Firebase.RTDB.setJSON(
        &fbdo,
        root + "/actuators",
        &actuatorJson))
    {
        lastActuatorState =
            current;

        Serial.println(
            "Actuator State Changed");
    }
}

void FirebaseManager::writeDeviceInfo()
{
    static unsigned long
    lastDeviceInfoUpload = 0;

    if(lastDeviceInfoUpload != 0 &&
    millis() -
    lastDeviceInfoUpload <
    60000)
    {
        return;
    }

    lastDeviceInfoUpload =
        millis();

    String root =
        "/devices/" +
        String(DEVICE_ID);

    FirebaseJson infoJson;

    infoJson.set(
        "deviceName",
        DEVICE_NAME);

    infoJson.set(
        "firmwareVersion",
        FIRMWARE_VERSION);

    infoJson.set(
    "online",
    systemState.firebaseConnected);

    infoJson.set(
        "lastSeen",
        millis());

    Firebase.RTDB.setJSON(
        &fbdo,
        root +
        "/deviceInfo",
        &infoJson);
}