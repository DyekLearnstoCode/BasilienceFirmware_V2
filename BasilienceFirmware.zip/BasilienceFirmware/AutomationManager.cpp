#include "AutomationManager.h"

#include "Config.h"
#include "Globals.h"

void AutomationManager::begin()
{
    startupPhase = STARTUP_FOG_ON;

    fogCycleOn = true;

    systemState.currentMode =
        SENSOR_STABILIZATION;

    systemState.stateStartTime =
        millis();
}

void AutomationManager::update()
{
    //--------------------------------------------------
    // Operation lifecycle
    //--------------------------------------------------

    if(systemState.operationRequest.state ==
       RequestState::ACCEPTED)
    {
        systemState.operationRequest.state =
            RequestState::RUNNING;

        systemState.operationRequest.startedTimestamp =
            millis();

        systemState.operationRequest.lastUpdatedTimestamp =
            systemState.operationRequest.startedTimestamp;

        return;
    }

    if(systemState.operationRequest.state ==
       RequestState::RUNNING)
    {
        processOperationRequest();
        return;
    }

    //--------------------------------------------------
    // RTC synchronization
    //--------------------------------------------------

    if(systemState.syncRTC)
    {
        systemState.syncRTC = false;

        syncRTCFromFirebase();

        return;
    }

    //--------------------------------------------------
    // Manual mode
    //--------------------------------------------------

    if(systemState.manualMode)
    {
        return;
    }

    //--------------------------------------------------
    // Safety reset
    //--------------------------------------------------

    if(systemState.resetSafetyLock)
    {
        systemState.resetSafetyLock = false;

        if(systemState.currentMode ==
           SAFETY_LOCK)
        {
            Serial.println(
                "SAFETY LOCK RESET");

            changeState(
                STARTUP);

            return;
        }
    }

    //--------------------------------------------------
    // State Machine
    //--------------------------------------------------

    processCurrentState();

} //Core Framework

void AutomationManager::processCurrentState()
{
    switch(systemState.currentMode)
    {
        case SENSOR_STABILIZATION:
            handleSensorStabilization();
            break;

        case STARTUP:
            handleStartup();
            break;

        case NORMAL:
            handleNormal();
            break;

        case REFILLING:
            handleRefilling();
            break;

        case DOSING_PH:
            handleDosingPH();
            break;

        case STABILIZING_PH:
            handleStabilizingPH();
            break;

        case DOSING_EC:
            handleDosingEC();
            break;

        case STABILIZING_EC:
            handleStabilizingEC();
            break;

        case SAFETY_LOCK:
            handleSafetyLock();
            break;

        default:
            break;
    }
}

//Operation Request Processing
void AutomationManager::processOperationRequest()
{
    switch(systemState.operationRequest.operation)
    {
        case OperationType::REFILL:
            processRefillOperation();
            break;

        case OperationType::PH_UP:
            processPHUpOperation();
            break;

        case OperationType::PH_DOWN:
            processPHDownOperation();
            break;


        case OperationType::RESET_SAFETY:
            processResetSafetyOperation();
            break;

        case OperationType::EC_CORRECTION:
        processECCorrectionOperation();
        break;

        default:
            break;
    }
}

//Operation Helpers

//Refill Operation
void AutomationManager::processRefillOperation()
{
    if(systemState.operationRequest.action !=
       OperationAction::START)
    {
        return;
    }

    SafetyResult result =
        safetyManager.canRefill();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return;
    }

    changeState(
        REFILLING);
}

//PH Up Operation
void AutomationManager::processPHUpOperation()
{
    if(systemState.operationRequest.action !=
       OperationAction::START)
    {
        return;
    }

    SafetyResult result =
        safetyManager.canDosePH();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return;
    }

    systemState.phDirection =
        PH_UP;

        systemState.correctionMode =
    CorrectionMode::MANUAL;

    systemState.firstCorrectionCycle = true;
    changeState(
        DOSING_PH);
}

//PH Down Operation
void AutomationManager::processPHDownOperation()
{
    if(systemState.operationRequest.action !=
       OperationAction::START)
    {
        return;
    }

    SafetyResult result =
        safetyManager.canDosePH();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return;
    }

    systemState.phDirection =
        PH_DOWN;

    systemState.correctionMode =
    CorrectionMode::MANUAL;

    systemState.firstCorrectionCycle = true;

    changeState(
        DOSING_PH);
}

//reset Safety Lock Operation
void AutomationManager::processResetSafetyOperation()
{
    if(systemState.operationRequest.action !=
       OperationAction::START)
    {
        return;
    }

    if(systemState.currentMode ==
       SAFETY_LOCK)
    {
        changeState(
            STARTUP);
    }
}

//System Validation
void AutomationManager::validateSystem()
{
    alertManager.update();

    if(alertState.lowWater)
    {
        SafetyResult result =
            safetyManager.canRefill();

        if(result != SafetyResult::SAFE)
        {
            failCurrentOperation(
                safetyManager.getSafetyReason(result));

            return;
        }

        changeState(
            REFILLING);

        return;
    }

    changeState(
        STARTUP);
}


//Operation Completion
void AutomationManager::completeCurrentOperation()
{

    if(systemState.operationRequest.state !=
       RequestState::RUNNING)
    {
        return;
    }

    systemState.operationRequest.state =
        RequestState::COMPLETED;

    systemState.operationRequest.completedTimestamp =
        millis();

    systemState.operationRequest.lastUpdatedTimestamp =
        systemState.operationRequest.completedTimestamp;

        systemState.correctionMode =
    CorrectionMode::NONE;

    systemState.firstCorrectionCycle = true;
}


//Operation Failure
void AutomationManager::failCurrentOperation(const String& reason)
{
    if(systemState.operationRequest.state !=
       RequestState::RUNNING)
    {
        return;
    }

    systemState.operationRequest.state =
        RequestState::FAILED;

    strncpy(
        systemState.operationRequest.reason,
        reason.c_str(),
        sizeof(systemState.operationRequest.reason) - 1);

    systemState.operationRequest.reason[
        sizeof(systemState.operationRequest.reason) - 1] = '\0';

    systemState.operationRequest.completedTimestamp =
        millis();

    systemState.operationRequest.lastUpdatedTimestamp =
        systemState.operationRequest.completedTimestamp;

        systemState.correctionMode =
    CorrectionMode::NONE;

    systemState.firstCorrectionCycle = true;

}

//RTC Synchronization
void AutomationManager::syncRTCFromFirebase()
{
    Serial.println(
        "RTC SYNC REQUESTED");
}

//State Change
void AutomationManager::changeState(SystemMode newMode)
{
    SystemMode oldMode =
        systemState.currentMode;

    Serial.println();
    Serial.println("================================");
    Serial.println("STATE CHANGE");
    Serial.println("================================");

    if(newMode == DOSING_PH)
    {
        if(systemState.phDirection == PH_UP)
        {
            Serial.println(
                "PH UP CORRECTION");
        }
        else
        {
            Serial.println(
                "PH DOWN CORRECTION");
        }

        Serial.print(
            "Dose Time : ");

        Serial.print(
            systemState.phDoseTime / 1000);

        Serial.println(
            " sec");
    }

    if(newMode == DOSING_EC)
    {
        Serial.println(
            "EC CORRECTION");

        Serial.print(
            "Dose Time : ");

        Serial.print(
            systemState.ecDoseTime / 1000);

        Serial.println(
            " sec");
    }

    Serial.print("FROM : ");
    Serial.println(
        getStateName(oldMode));

    Serial.print("TO   : ");
    Serial.println(
        getStateName(newMode));

    if(newMode == SAFETY_LOCK)
    {
        Serial.println(
            "!!! SAFETY LOCK ACTIVATED !!!");
    }

    Serial.println("================================");
    Serial.println();

    systemState.currentMode =
        newMode;

    systemState.stateStartTime =
        millis();
}

//sensor stabilization
void AutomationManager::handleSensorStabilization()
{
    actuatorManager.turnOff(FOGGER);

    actuatorManager.turnOff(BLOWER);

    if(millis() -
       systemState.stateStartTime >=
       SENSOR_STABILIZATION_TIME)
    {
        validateSystem();
    }
}


//Startup
void AutomationManager::handleStartup()
{
    if(systemState.reservoirLocked)
    {
        return;
    }

    switch(startupPhase)
    {
        case STARTUP_FOG_ON:
        {
            actuatorManager.turnOn(FOGGER);
            actuatorManager.turnOn(BLOWER);

            if(millis() -
               systemState.stateStartTime >=
               STARTUP_ON_TIME)
            {
                actuatorManager.turnOff(FOGGER);
                actuatorManager.turnOff(BLOWER);

                startupPhase =
                    STARTUP_FOG_OFF;

                systemState.stateStartTime =
                    millis();
            }

            break;
        }

        case STARTUP_FOG_OFF:
        {
            actuatorManager.turnOff(FOGGER);
            actuatorManager.turnOff(BLOWER);

            if(millis() -
               systemState.stateStartTime >=
               STARTUP_OFF_TIME)
            {
                fogCycleOn = true;

                changeState(
                    NORMAL);
            }

            break;
        }
    }
}

//Normal Operation
void AutomationManager::handleNormal()
{
    updateGrowLightSchedule();

    alertManager.update();

    if(!validateNormalOperation())
    {
        return;
    }

    updateCooling();

    if(processRefillRequest())
    {
        return;
    }

    if(processPHCorrection())
    {
        return;
    }

    if(processECCorrection())
    {
        return;
    }

    processFogCycle();
}

//safety Lock Handling
bool AutomationManager::validateNormalOperation()
{
    SafetyResult result =
        safetyManager.canFog();

    if(result != SafetyResult::SAFE)
    {
        actuatorManager.turnOff(FOGGER);
        actuatorManager.turnOff(BLOWER);

        Serial.println(
            safetyManager.getSafetyReason(result));

        return false;
    }

    return true;
}

//Cooling Handling
void AutomationManager::updateCooling()
{
    SafetyResult result =
        safetyManager.canCool();

    if(result != SafetyResult::SAFE)
    {
        actuatorManager.turnOff(
            PELTIER);

        return;
    }

    if(sensors.waterTemp >
       systemState.highWaterTemp)
    {
        actuatorManager.turnOn(
            PELTIER);
    }

    if(sensors.waterTemp <
       systemState.coolerOffTemp)
    {
        actuatorManager.turnOff(
            PELTIER);
    }
}

//force refill request
bool AutomationManager::processRefillRequest()
{
    if(!systemState.forceRefill)
    {
        return false;
    }

    systemState.forceRefill =
        false;

    changeState(
        REFILLING);

    return true;
}

//PH Correction Handling
bool AutomationManager::processPHCorrection()
{
    if(!alertState.phOutOfRange)
    {
        return false;
    }

    float error;

    if(sensors.ph <
       systemState.minPH)
    {
        systemState.phDirection =
            PH_UP;

        error =
            systemState.minPH -
            sensors.ph;
    }
    else
    {
        systemState.phDirection =
            PH_DOWN;

        error =
            sensors.ph -
            systemState.maxPH;
    }

    if(error < 0.3f)
    {
        systemState.phDoseTime =
            15000UL;
    }
    else if(error < 1.0f)
    {
        systemState.phDoseTime =
            30000UL;
    }
    else
    {
        systemState.phDoseTime =
            60000UL;
    }

    SafetyResult result =
        safetyManager.canDosePH();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return true;
    }

    systemState.correctionMode =
    CorrectionMode::AUTOMATIC;

    systemState.firstCorrectionCycle = true;

    changeState(
        DOSING_PH);

    return true;
}

//EC Correction Handling
bool AutomationManager::processECCorrection()
{
    if(!alertState.ecLow)
    {
        return false;
    }

    float error =
        systemState.minEC -
        sensors.ec;

    if(error < 0.2f)
    {
        systemState.ecDoseTime =
            15000UL;
    }
    else if(error < 0.5f)
    {
        systemState.ecDoseTime =
            30000UL;
    }
    else
    {
        systemState.ecDoseTime =
            60000UL;
    }

    SafetyResult result =
        safetyManager.canDoseEC();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return true;
    }

    systemState.correctionMode =
    CorrectionMode::AUTOMATIC;

    systemState.firstCorrectionCycle = true;

    changeState(
        DOSING_EC);

    return true;
}

void AutomationManager::processECCorrectionOperation()
{
    if(systemState.operationRequest.action !=
       OperationAction::START)
    {
        return;
    }

    SafetyResult result =
        safetyManager.canDoseEC();

    if(result != SafetyResult::SAFE)
    {
        failCurrentOperation(
            safetyManager.getSafetyReason(result));

        return;
    }

    systemState.correctionMode =
        CorrectionMode::MANUAL;

        systemState.firstCorrectionCycle = true;

    changeState(
        DOSING_EC);
}

//Fog Cycle Handling
void AutomationManager::processFogCycle()
{
    unsigned long elapsed =
        millis() -
        systemState.stateStartTime;

    unsigned long fogOnTime =
        NORMAL_FOG_ON_TIME;

    unsigned long fogOffTime =
        NORMAL_FOG_OFF_TIME;

    if(sensors.temperature >
       systemState.hotFogTemperature)
    {
        fogOnTime =
            HOT_FOG_ON_TIME;

        fogOffTime =
            HOT_FOG_OFF_TIME;
    }
    else if(sensors.temperature <
            systemState.coldFogTemperature)
    {
        fogOnTime =
            COLD_FOG_ON_TIME;

        fogOffTime =
            COLD_FOG_OFF_TIME;
    }

    if(fogCycleOn)
    {
        actuatorManager.turnOn(
            FOGGER);

        actuatorManager.turnOn(
            BLOWER);

        if(elapsed >= fogOnTime)
        {
            fogCycleOn = false;

            systemState.stateStartTime =
                millis();
        }
    }
    else
    {
        actuatorManager.turnOff(
            FOGGER);

        actuatorManager.turnOff(
            BLOWER);

        if(elapsed >= fogOffTime)
        {
            fogCycleOn = true;

            systemState.stateStartTime =
                millis();
        }
    }
}

//Grow Light Schedule Handling
void AutomationManager::updateGrowLightSchedule()
{
    bool lightEnabled =
        isWithinSchedule(
            systemState.lightOnHour,
            systemState.lightOnMinute,
            systemState.lightOffHour,
            systemState.lightOffMinute);

    if(lightEnabled)
    {
        actuatorManager.turnOn(
            GROW_LIGHT);
    }
    else
    {
        actuatorManager.turnOff(
            GROW_LIGHT);
    }
}
//Get Current Time in Minutes
int AutomationManager::getCurrentMinutes() const
{
    return
        rtcManager.getHour() * 60 +
        rtcManager.getMinute();
}
//Schedule Validation
bool AutomationManager::isWithinSchedule(
    uint8_t startHour,
    uint8_t startMinute,
    uint8_t endHour,
    uint8_t endMinute) const
{
    const int current =
        getCurrentMinutes();

    const int start =
        startHour * 60 +
        startMinute;

    const int end =
        endHour * 60 +
        endMinute;

    // Normal schedule
    if(start < end)
    {
        return
            current >= start &&
            current < end;
    }

    // Overnight schedule
    return
        current >= start ||
        current < end;
}

//Refilling Handling
void AutomationManager::handleRefilling()
{
    alertManager.update();

    SafetyResult result =
        safetyManager.canRefill();

    if(result != SafetyResult::SAFE)
    {
        abortCurrentOperation(result);
        return;
    }

    systemState.reservoirLocked = true;

    actuatorManager.turnOn(
        SOLENOID);

    if(sensors.waterLevel >=
       systemState.refillStopLevel)
    {
        actuatorManager.turnOff(
            SOLENOID);

        systemState.reservoirLocked = false;

        completeCurrentOperation();

        changeState(
            STARTUP);

    }
}

//handle ph dosing
void AutomationManager::handleDosingPH()
{
    alertManager.update();

    SafetyResult result =
        safetyManager.canDosePH();

    if(result != SafetyResult::SAFE)
    {
        abortCurrentOperation(result);
        return;
    }

    systemState.reservoirLocked = true;

    if(systemState.phDirection == PH_UP)
    {
        actuatorManager.turnOn(PH_UP_PUMP);
        actuatorManager.turnOff(PH_DOWN_PUMP);
    }
    else
    {
        actuatorManager.turnOn(PH_DOWN_PUMP);
        actuatorManager.turnOff(PH_UP_PUMP);
    }

    bool stopDosing = false;

    if(systemState.correctionMode ==
       CorrectionMode::MANUAL &&
       systemState.firstCorrectionCycle)
    {
        if(!alertState.phOutOfRange)
        {
            stopDosing = true;
        }

        if(millis() -
           systemState.stateStartTime >=
           systemState.phDoseTime)
        {
            stopDosing = true;
        }
    }
    else
    {
        if(millis() -
           systemState.stateStartTime >=
           systemState.phDoseTime)
        {
            stopDosing = true;
        }
    }

    if(stopDosing)
    {
        actuatorManager.turnOff(PH_UP_PUMP);
        actuatorManager.turnOff(PH_DOWN_PUMP);

        changeState(STABILIZING_PH);
    }
}

//handle ph stabilization
void AutomationManager::handleStabilizingPH()
{
    alertManager.update();

    SafetyResult result =
        safetyManager.canDosePH();

    if(result != SafetyResult::SAFE)
    {
        abortCurrentOperation(result);
        return;
    }

    actuatorManager.turnOff(
        PH_UP_PUMP);

    actuatorManager.turnOff(
        PH_DOWN_PUMP);

    if(millis() -
       systemState.stateStartTime >=
       PH_STABILIZATION_TIME)
    {
        if(alertState.phOutOfRange)
        {
            systemState.phAttempts++;

            if(systemState.phAttempts >=
               MAX_PH_ATTEMPTS)
            {
                changeState(
                    SAFETY_LOCK);

                return;
            }


            systemState.firstCorrectionCycle = false;

            changeState(
                DOSING_PH);

            return;
        }

        systemState.phAttempts = 0;

        systemState.phDirection = PH_NONE;

        systemState.reservoirLocked = false;

        completeCurrentOperation();

        changeState(
            NORMAL);
    }
}

//handle ec dosing
void AutomationManager::handleDosingEC()
{
    alertManager.update();

    SafetyResult result =
        safetyManager.canDoseEC();

    if(result != SafetyResult::SAFE)
    {
        abortCurrentOperation(result);
        return;
    }

    systemState.reservoirLocked = true;

    actuatorManager.turnOn(GROW_PUMP);
    actuatorManager.turnOn(BLOOM_PUMP);

    bool stopDosing = false;

    if(systemState.correctionMode ==
       CorrectionMode::MANUAL &&
       systemState.firstCorrectionCycle)
    {
        if(!alertState.ecLow)
        {
            stopDosing = true;
        }

        if(millis() -
           systemState.stateStartTime >=
           systemState.ecDoseTime)
        {
            stopDosing = true;
        }
    }
    else
    {
        if(millis() -
           systemState.stateStartTime >=
           systemState.ecDoseTime)
        {
            stopDosing = true;
        }
    }

    if(stopDosing)
    {
        actuatorManager.turnOff(GROW_PUMP);
        actuatorManager.turnOff(BLOOM_PUMP);

        changeState(STABILIZING_EC);
    }
}

//handle ec stabilization
void AutomationManager::handleStabilizingEC()
{
    alertManager.update();

    SafetyResult result =
        safetyManager.canDoseEC();

    if(result != SafetyResult::SAFE)
    {
        abortCurrentOperation(result);
        return;
    }

    actuatorManager.turnOff(
        GROW_PUMP);

    actuatorManager.turnOff(
        BLOOM_PUMP);

    if(millis() -
       systemState.stateStartTime >=
       EC_STABILIZATION_TIME)
    {
        alertManager.update();

        if(alertState.ecLow)
        {
            systemState.ecAttempts++;

            if(systemState.ecAttempts >=
               MAX_EC_ATTEMPTS)
            {
                changeState(
                    SAFETY_LOCK);

                return;
            }

            systemState.firstCorrectionCycle = false;

            float error =
                systemState.minEC -
                sensors.ec;

            if(error < 0.2f)
            {
                systemState.ecDoseTime =
                    15000UL;
            }
            else if(error < 0.5f)
            {
                systemState.ecDoseTime =
                    30000UL;
            }
            else
            {
                systemState.ecDoseTime =
                    60000UL;
            }

            changeState(
                DOSING_EC);

            return;
        }

        systemState.ecAttempts = 0;

        systemState.reservoirLocked = false;

        completeCurrentOperation();

        changeState(
            NORMAL);
    }
}

//handle safety lock
void AutomationManager::handleSafetyLock()
{
    actuatorManager.turnOffAll();

    systemState.reservoirLocked = true;
}

//get state name
const char* AutomationManager::getStateName(SystemMode mode)
{
    switch(mode)
    {
        case SENSOR_STABILIZATION:
            return "SENSOR_STABILIZATION";

        case STARTUP:
            return "STARTUP";

        case NORMAL:
            return "NORMAL";

        case REFILLING:
            return "REFILLING";

        case DOSING_PH:
            return "DOSING_PH";

        case STABILIZING_PH:
            return "STABILIZING_PH";

        case DOSING_EC:
            return "DOSING_EC";

        case STABILIZING_EC:
            return "STABILIZING_EC";

        case SAFETY_LOCK:
            return "SAFETY_LOCK";

        default:
            return "UNKNOWN";
    }
}

bool AutomationManager::abortCurrentOperation(
    SafetyResult result)
{
    actuatorManager.turnOffAll();

    systemState.reservoirLocked = true;

    failCurrentOperation(
        safetyManager.getSafetyReason(result));

    changeState(
        SAFETY_LOCK);

    return true;
}