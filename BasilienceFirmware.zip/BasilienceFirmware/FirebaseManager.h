#ifndef FIREBASE_MANAGER_H
#define FIREBASE_MANAGER_H

#include <WiFi.h>

#include <Firebase_ESP_Client.h>

class FirebaseManager
{
public:

    void begin();

    void update();

private:

    FirebaseData fbdo;

    FirebaseAuth auth;

    FirebaseConfig config;

    FirebaseJson json;

    unsigned long lastSettingsRead = 0;

    void readSettings();
    void syncRTC();
    void readCommands();

    void writeSensors();

    void writeStatus();
    void writeTelemetry();
    void writeDeviceInfo();

    void writeAlerts();
    void writeActuators();
    ActuatorTelemetry lastActuatorState;
};

#endif