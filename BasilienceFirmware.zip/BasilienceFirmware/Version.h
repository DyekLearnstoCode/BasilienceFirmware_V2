#ifndef VERSION_H
#define VERSION_H

constexpr char DEFAULT_DEVICE_ID[] = "";
constexpr char DEVICE_NAME[] = "Basilience Controller";
constexpr char FIRMWARE_VERSION[] = "2.0.0";

#endif